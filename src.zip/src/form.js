const { goToConsultaCausas } = require('./navigation');
const { detectCaptcha, checkIfBlocked } = require('./utils/captcha-detector');

// Función para resetear el formulario (volver a estado inicial)
async function resetForm(page) {
  try {
    // Verificar si ya estamos en el formulario
    const currentUrl = page.url();
    const isOnFormPage = currentUrl.includes('consulta') || currentUrl.includes('causa') || 
                         await page.$('#competencia') !== null;
    
    if (!isOnFormPage) {
      console.log('🔄 Volviendo al formulario...');
      await goToConsultaCausas(page);
    } else {
      // Ya estamos en el formulario, solo cerrar modales si existen
      try {
        // Cerrar modales con ESC
        await page.keyboard.press('Escape');
        await page.waitForTimeout(300);
        
        // Intentar cerrar botones de cerrar modal
        const closeSelectors = [
          'button.close',
          '.modal-header button',
          '[data-dismiss="modal"]',
          'button[aria-label="Close"]'
        ];
        
        for (const selector of closeSelectors) {
          try {
            const closeBtn = await page.$(selector);
            if (closeBtn && await closeBtn.isVisible()) {
              await closeBtn.click();
              await page.waitForTimeout(300);
            }
          } catch (e) {
            continue;
          }
        }
      } catch (e) {
        // No hay modal, continuar
      }
    }
    
    // Esperar a que el formulario esté disponible
    await page.waitForSelector('#competencia', { timeout: 30000 }); // Aumentado de 20s a 30s
    
    // Limpiar campos - solo hacer click para enfocar, no resetear valores
    // (reseteamos solo si es necesario, pero normalmente solo necesitamos que esté visible)
    await page.waitForTimeout(300);
    
  } catch (error) {
    console.warn('⚠️ No se pudo resetear formulario:', error.message);
    // No lanzar error, solo continuar
  }
}

async function fillForm(page, CONFIG) {
  console.log('📝 Llenando formulario...');

  try {
    // Cerrar modales si existen (sin navegar si ya estamos en el formulario)
    try {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
    } catch (e) {
      // Ignorar si no hay modal
    }
    
    // Verificar que estamos en el formulario
    let hasForm = false;
    try {
      const competencia = await page.$('#competencia');
      hasForm = competencia !== null && await competencia.isVisible();
    } catch (e) {
      hasForm = false;
    }
    
    if (!hasForm) {
      // Solo navegar si realmente no estamos en el formulario
      console.log('🔄 No estamos en el formulario, navegando...');
      await resetForm(page);
    } else {
      // Ya estamos en el formulario, solo cerrar modales
      console.log('✅ Ya estamos en el formulario, cerrando modales...');
      try {
        // Cerrar modales múltiples veces para asegurar
        for (let i = 0; i < 3; i++) {
          await page.keyboard.press('Escape');
          await page.waitForTimeout(200);
        }
        
        // Intentar cerrar botones de cerrar modal
        const closeSelectors = ['button.close', '.modal-header button', '[data-dismiss="modal"]'];
        for (const selector of closeSelectors) {
          try {
            const btn = await page.$(selector);
            if (btn && await btn.isVisible()) {
              await btn.click();
              await page.waitForTimeout(200);
            }
          } catch (e) {
            continue;
          }
        }
      } catch (e) {
        // Ignorar si no hay modal
      }
    }
    
    // Screenshot solo si no está en modo headless (deshabilitado en headless)
    // await page.screenshot({ path: 'debug_06_antes_formulario.png', fullPage: false });
    // console.log('📸 Screenshot: debug_06_antes_formulario.png');
    
    // Esperar a que el formulario esté disponible
    console.log('⏳ Esperando formulario...');
    await page.waitForSelector('#competencia', { timeout: 30000 }); // Aumentado de 20s a 30s
    console.log('✅ Formulario disponible');
    
    // Delay optimizado antes de empezar a escribir (200-500ms)
    await page.waitForTimeout(200 + Math.random() * 300);

    // Llenar campos como humano (con delays variables)
    // El formulario tiene dependencias: competencia → corte → tribunal → tipoCausa
    
    // 1. Seleccionar competencia (SIEMPRE Civil = 3, todas las causas con RIT son civiles)
    const competencia = CONFIG.competencia || '3'; // Default a Civil
    console.log(`📋 Competencia: ${competencia} (Civil - todas las causas con RIT son civiles)`);
    await page.selectOption('#competencia', competencia);
    await page.waitForTimeout(200 + Math.random() * 300); // Optimizado: reducido de 500-1000ms a 200-500ms
    
    // 2. Esperar a que se habilite Corte y seleccionarlo (opcional)
    const corte = CONFIG.corte || '90'; // Default
    console.log(`📋 Corte: ${corte}`);
    try {
      // Esperar a que el campo se habilite (no esté disabled)
      await page.waitForFunction(
        () => {
          const corteSelect = document.querySelector('#conCorte');
          return corteSelect && !corteSelect.disabled && corteSelect.options.length > 1;
        },
        { timeout: 20000 } // Aumentado de 15s a 20s para evitar timeouts
      );
      console.log('✅ Campo Corte habilitado');
      
      await page.waitForTimeout(300 + Math.random() * 400); // Optimizado: reducido de 1000-2000ms a 300-700ms
      
      // Verificar que la opción existe antes de seleccionar
      const corteExists = await page.evaluate((corteValue) => {
        const select = document.querySelector('#conCorte');
        if (!select) return false;
        const options = Array.from(select.options);
        return options.some(opt => opt.value === corteValue || opt.value === String(corteValue));
      }, corte);
      
      if (corteExists) {
        await page.selectOption('#conCorte', corte);
        console.log('✅ Corte seleccionado');
      } else {
        console.warn(`⚠️ Corte ${corte} no encontrado, continuando sin corte...`);
      }
    } catch (error) {
      console.warn('⚠️ No se pudo seleccionar corte, continuando sin corte...');
    }
    await page.waitForTimeout(200 + Math.random() * 300); // Optimizado

    // 3. Tribunal: SIEMPRE omitido para optimizar velocidad
    // Todas las causas con RIT son civiles, tribunal es opcional y ralentiza el proceso
    console.log('📋 Tribunal: Omitido (optimización: siempre buscar sin tribunal)');
    // No esperamos ni seleccionamos tribunal - ahorra 1-3 segundos por causa

    // 4. Esperar a que se habilite Tipo Causa y seleccionarlo
    console.log(`📋 Tipo Causa: ${CONFIG.tipoCausa}`);
    try {
      await page.waitForFunction(
        () => {
          const tipoCausa = document.querySelector('#conTipoCausa');
          return tipoCausa && !tipoCausa.disabled && tipoCausa.options.length > 1;
        },
        { timeout: 20000 } // Aumentado de 15s a 20s para evitar timeouts
      );
      console.log('✅ Campo Tipo Causa habilitado');
    } catch (error) {
      console.warn('⚠️ Campo Tipo Causa no se habilitó automáticamente, intentando forzar...');
      await page.evaluate(() => {
        const tipoCausa = document.querySelector('#conTipoCausa');
        if (tipoCausa) tipoCausa.removeAttribute('disabled');
      });
    }
    await page.waitForTimeout(200 + Math.random() * 300); // Optimizado // Esperar a que se carguen opciones
    await page.selectOption('#conTipoCausa', CONFIG.tipoCausa);
    await page.waitForTimeout(200 + Math.random() * 300); // Optimizado

    // Extraer rol y año del RIT
    // Formatos posibles:
    // - "C-13786-2018" → rol: "13786", año: "2018" (3 partes)
    // - "16707-2019" → rol: "16707", año: "2019" (2 partes)
    let rol = '';
    let año = '';
    
    if (CONFIG.rit) {
      const parts = CONFIG.rit.split('-');
      if (parts.length >= 3) {
        // Formato: "C-13786-2018" (tipo-rol-año)
        rol = parts[1]; // Segunda parte es el rol
        año = parts[2]; // Tercera parte es el año
      } else if (parts.length === 2) {
        // Formato: "16707-2019" (rol-año)
        rol = parts[0]; // Primera parte es el rol
        año = parts[1]; // Segunda parte es el año
      }
    }
    
    console.log(`📋 Rol: ${rol || 'N/A'}, Año: ${año || 'N/A'}`);
    
    // Escribir como humano (con delay de escritura)
    if (rol) {
      await page.fill('#conRolCausa', rol);
      await page.waitForTimeout(150 + Math.random() * 250); // Optimizado: reducido de 400-1000ms a 150-400ms
    }
    
      if (año) {
      await page.fill('#conEraCausa', año);
      await page.waitForTimeout(150 + Math.random() * 250); // Optimizado: reducido de 400-1000ms a 150-400ms
    }

    // Screenshot deshabilitado en modo headless
    // await page.screenshot({ path: 'debug_07_formulario_llenado.png', fullPage: false });
    // console.log('📸 Screenshot: debug_07_formulario_llenado.png');

  console.log("🔍 Buscando...");

    // Buscar el botón de varias formas
    const buttonSelectors = [
      'input[value="Buscar"]',
      'button:has-text("Buscar")',
      'input[type="submit"]',
      'button[type="submit"]'
    ];
    
    let buttonClicked = false;
    for (const selector of buttonSelectors) {
      try {
        await page.waitForSelector(selector, { timeout: 10000 }); // Aumentado de 5s a 10s
        await page.click(selector);
        buttonClicked = true;
        console.log(`✅ Botón encontrado y clickeado: ${selector}`);
        break;
      } catch (error) {
        continue;
      }
    }
    
    if (!buttonClicked) {
      await page.screenshot({ path: 'debug_error_boton_buscar.png', fullPage: true });
      throw new Error('No se pudo encontrar el botón "Buscar"');
    }
    
    // Verificar CAPTCHA antes de continuar (solo si está realmente bloqueando)
    const captchaCheck = await detectCaptcha(page);
    const blockCheck = await checkIfBlocked(page);
    
    if (captchaCheck.detected || blockCheck.blocked) {
      // Si es CAPTCHA activo o bloqueo real, notificar y detener (NO reintentar)
      if (captchaCheck.type === 'recaptcha-active' || blockCheck.blocked) {
        const errorType = captchaCheck.detected ? captchaCheck.type : blockCheck.reason;
        
        console.error('\n🚨 ============================================');
        console.error('🚨 BLOQUEO/CAPTCHA DETECTADO - DETENIENDO');
        console.error('🚨 ============================================');
        console.error(`\n❌ Tipo: ${errorType}`);
        console.error(`📋 Razón: ${blockCheck.blocked ? blockCheck.reason : captchaCheck.type}`);
        console.error('\n📝 ACCIÓN REQUERIDA:');
        console.error('   1. Espera 30-60 minutos antes de reintentar');
        console.error('   2. Considera usar una VPN o cambiar tu IP');
        console.error('   3. Reduce la velocidad de scraping si continúas');
        console.error('   4. Verifica manualmente en el navegador si el bloqueo persiste');
        console.error('\n⏸️  El proceso se ha detenido para evitar empeorar el bloqueo.');
        console.error('🚨 ============================================\n');
        
        // Guardar screenshot para diagnóstico
        const screenshotPath = `src/logs/bloqueo_${Date.now()}.png`;
        await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});
        console.error(`📸 Screenshot guardado: ${screenshotPath}`);
        
        throw new Error(`CAPTCHA/Bloqueo detectado - Deteniendo ejecución: ${errorType}`);
      } else {
        // Solo advertencia si no está realmente activo (solo script presente)
        console.warn(`⚠️ Script de reCAPTCHA detectado pero inactivo, continuando...`);
      }
    }
    
    // Esperar resultado (timeout aumentado para evitar fallos)
    await page.waitForLoadState('domcontentloaded', { timeout: 20000 }).catch(() => {
      console.warn('⚠️ Timeout esperando resultado de búsqueda, continuando...');
    });
    await page.waitForTimeout(800 + Math.random() * 700); // Aumentado a 0.8-1.5s para dar tiempo a cargar
    
    // Verificar CAPTCHA después de la búsqueda - NOTIFICAR Y DETENER si hay bloqueo
    const captchaCheckAfter = await detectCaptcha(page);
    const blockCheckAfter = await checkIfBlocked(page);
    
    // Si hay bloqueo o CAPTCHA activo, notificar y detener (NO reintentar)
    if (blockCheckAfter.blocked || (captchaCheckAfter.detected && captchaCheckAfter.type === 'recaptcha-active')) {
      const errorType = blockCheckAfter.blocked ? blockCheckAfter.reason : captchaCheckAfter.type;
      
      console.error('\n🚨 ============================================');
      console.error('🚨 BLOQUEO/CAPTCHA DETECTADO DESPUÉS DE BÚSQUEDA');
      console.error('🚨 ============================================');
      console.error(`\n❌ Tipo: ${errorType}`);
      console.error(`📋 Ubicación: Después de buscar en el formulario`);
      console.error('\n📝 ACCIÓN REQUERIDA:');
      console.error('   1. Espera 30-60 minutos antes de reintentar');
      console.error('   2. Considera usar una VPN o cambiar tu IP');
      console.error('   3. Reduce la velocidad de scraping');
      console.error('\n⏸️  El proceso se ha detenido para evitar empeorar el bloqueo.');
      console.error('🚨 ============================================\n');
      
      // Guardar screenshot para diagnóstico
      const screenshotPath = `src/logs/bloqueo_despues_busqueda_${Date.now()}.png`;
      await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});
      console.error(`📸 Screenshot guardado: ${screenshotPath}`);
      
      throw new Error(`Bloqueo/CAPTCHA detectado después de búsqueda - Deteniendo ejecución: ${errorType}`);
    }
    
    // Screenshot deshabilitado en modo headless
    // await page.screenshot({ path: 'debug_08_despues_buscar.png', fullPage: false });
    // console.log('📸 Screenshot: debug_08_despues_buscar.png');
    
    console.log('✅ Formulario enviado');
    
  } catch (error) {
    console.error('❌ Error llenando formulario:', error.message);
    await page.screenshot({ path: 'debug_error_formulario.png', fullPage: true });
    throw error;
  }
}

/**
 * Abre el detalle de una causa específica haciendo match por caratulado y tribunal
 * @param {Page} page - Página de Playwright
 * @param {string} caratulado - Caratulado para hacer match (opcional)
 * @param {string} tribunalNombre - Nombre del tribunal para hacer match (opcional)
 */
async function openDetalleEspecifico(page, caratulado, tribunalNombre) {
  try {
    console.log("🔍 Buscando causa específica...");
    if (caratulado) console.log(`   📋 Caratulado: ${caratulado}`);
    if (tribunalNombre) console.log(`   🏛️  Tribunal: ${tribunalNombre}`);

    // Esperar a que la tabla de resultados tenga filas
    await page.waitForFunction(() => {
      const rows = document.querySelectorAll('table tbody tr');
      return rows.length > 0;
    }, { timeout: 15000 });

    await page.waitForTimeout(1000);

    // Buscar la fila que coincide con caratulado y/o tribunal
    const clicked = await page.evaluate(({ caratulado, tribunalNombre }) => {
      const rows = document.querySelectorAll('table tbody tr');

      for (const row of rows) {
        const cells = Array.from(row.querySelectorAll('td'));
        if (cells.length < 4) continue;

        // Extraer texto de las celdas (típicamente: [icono, rit, fecha, caratulado, tribunal])
        const caratuladoCell = cells[3]?.innerText?.trim() || '';
        const tribunalCell = cells[4]?.innerText?.trim() || '';

        // Hacer match flexible (contiene o similar)
        const matchCaratulado = !caratulado || caratuladoCell.includes(caratulado) || caratulado.includes(caratuladoCell);
        const matchTribunal = !tribunalNombre || tribunalCell.includes(tribunalNombre) || tribunalNombre.includes(tribunalCell);

        if (matchCaratulado && matchTribunal) {
          // Encontrada la fila correcta
          const link = row.querySelector('td a') || row.querySelector('a');
          if (link) {
            console.log('✅ Match encontrado:', caratuladoCell, '|', tribunalCell);

            // Ejecutar el onclick handler manualmente (más confiable que click())
            const onclickAttr = link.getAttribute('onclick');
            if (onclickAttr) {
              console.log('🔧 Ejecutando onclick handler...');
              eval(onclickAttr); // Ejecutar el código JavaScript del onclick
            } else {
              link.click(); // Fallback si no hay onclick
            }

            return { success: true, caratulado: caratuladoCell, tribunal: tribunalCell };
          }
        }
      }

      return { success: false, message: 'No se encontró fila que coincida' };
    }, { caratulado, tribunalNombre });

    if (!clicked.success) {
      await page.screenshot({ path: 'debug_no_match_detalle.png', fullPage: true });
      throw new Error(`No se encontró causa con caratulado="${caratulado}" y tribunal="${tribunalNombre}"`);
    }

    console.log(`✅ Click ejecutado en: ${clicked.caratulado} - ${clicked.tribunal}`);

    // Esperar modal con más tiempo y mejor diagnóstico
    console.log("   ⏳ Esperando que se abra el modal...");
    await page.waitForTimeout(3000); // Dar más tiempo para el render inicial

    // Verificar si apareció CAPTCHA después del click
    const captchaDetectado = await page.evaluate(() => {
      return !!(
        document.querySelector('iframe[src*="recaptcha"]') ||
        document.querySelector('iframe[src*="hcaptcha"]') ||
        document.querySelector('.g-recaptcha') ||
        document.querySelector('.h-captcha') ||
        document.querySelector('[data-sitekey]')
      );
    });

    if (captchaDetectado) {
      await page.screenshot({ path: 'captcha_detectado.png', fullPage: true });
      throw new Error('🚨 CAPTCHA detectado después del click - requiere intervención manual');
    }

    try {
      await page.waitForFunction(() => {
        const modal = document.querySelector('#modalDetalleCivil, #modalDetalleLaboral, .modal.show, .modal[style*="display: block"]');
        if (!modal) {
          console.log('Modal no encontrado aún...');
          return false;
        }
        const tabla = modal.querySelector('table tbody tr');
        if (!tabla) {
          console.log('Modal encontrado pero sin tabla...');
          return false;
        }
        console.log('Modal con tabla detectado ✓');
        return true;
      }, { timeout: 30000 });

      console.log("✅ Modal con contenido detectado");
      console.log("✅ Detalle cargado.");
    } catch (e) {
      // Diagnóstico detallado si falla
      const diagnostico = await page.evaluate(() => {
        const modal = document.querySelector('#modalDetalleCivil, #modalDetalleLaboral, .modal.show, .modal[style*="display: block"]');
        if (!modal) return { modalExists: false };
        const style = window.getComputedStyle(modal);
        const tablas = modal.querySelectorAll('table');
        return {
          modalExists: true,
          modalDisplay: style.display,
          modalVisibility: style.visibility,
          tablesCount: tablas.length,
          hasRows: tablas.length > 0 && tablas[0].querySelectorAll('tbody tr').length > 0,
          rowsCount: tablas.length > 0 ? tablas[0].querySelectorAll('tbody tr').length : 0
        };
      });
      console.log('   ⚠️ Diagnóstico de modal:', JSON.stringify(diagnostico, null, 2));
      throw new Error(`Modal no cargó correctamente: ${JSON.stringify(diagnostico)}`);
    }
  } catch (error) {
    await page.screenshot({ path: 'error_detalle_especifico.png', fullPage: true });
    throw new Error(`Error abriendo detalle específico: ${error.message}`);
  }
}

async function openDetalle(page) {
  try {
    console.log("🔍 Buscando enlace 'Detalle de la causa'...");

    // Esperar a que la tabla de resultados tenga filas
    await page.waitForFunction(() => {
      const rows = document.querySelectorAll('table tbody tr');
      return rows.length > 0;
    }, { timeout: 15000 });

    await page.waitForTimeout(1000); // Esperar que la tabla termine de renderizar

    // Guardar URL actual para detectar navegación
    const urlAntes = page.url();

    // Buscar y hacer click usando JavaScript directamente
    // El enlace puede tener title="Detalle de la causa" o ser el primer <a> en la celda
    const clicked = await page.evaluate(() => {
      // Intentar primero con el selector original (compatibilidad hacia atrás)
      let link = document.querySelector('a[title="Detalle de la causa"]');

      if (!link) {
        // Buscar en la primera fila de la tabla de resultados
        const firstRow = document.querySelector('table tbody tr');
        if (firstRow) {
          // El enlace de la lupa suele estar en la primera celda
          link = firstRow.querySelector('td a') || firstRow.querySelector('a');
        }
      }

      if (link) {
        console.log('Encontrado enlace:', link.outerHTML.substring(0, 200));
        link.click();
        return true;
      }
      return false;
    });

    if (!clicked) {
      await page.screenshot({ path: 'debug_no_enlace_detalle.png', fullPage: true });
      throw new Error('No se encontró el enlace de detalle en la tabla de resultados');
    }

    console.log("✅ Click ejecutado en enlace de detalle");

    // Esperar a que algo cambie (modal o navegación)
    await page.waitForTimeout(2000);

    // Verificar si navegó a otra página
    const urlDespues = page.url();
    const navego = urlDespues !== urlAntes;

    if (navego) {
      console.log("📄 Navegó a página de detalle:", urlDespues);
      await page.waitForLoadState('domcontentloaded', { timeout: 30000 });
    } else {
      // Esperar el modal
      console.log("🔄 Esperando modal...");

      try {
        // Esperar que el modal sea visible
        await page.waitForFunction(() => {
          const modal = document.querySelector('#modalDetalleCivil, #modalDetalleLaboral, .modal.show, .modal[style*="display: block"]');
          if (!modal) return false;

          // Verificar que tenga contenido (tabla de historia)
          const tabla = modal.querySelector('table tbody tr');
          return tabla !== null;
        }, { timeout: 20000 });

        console.log("✅ Modal con contenido detectado");
      } catch (e) {
        // Verificar si el modal existe pero está vacío o cargando
        const modalState = await page.evaluate(() => {
          const modal = document.querySelector('#modalDetalleCivil, #modalDetalleLaboral');
          if (!modal) return { exists: false };

          const style = window.getComputedStyle(modal);
          return {
            exists: true,
            display: style.display,
            visibility: style.visibility,
            hasShow: modal.classList.contains('show'),
            innerHTML: modal.innerHTML.substring(0, 500)
          };
        });

        console.log("Estado del modal:", JSON.stringify(modalState, null, 2));

        if (modalState.exists && (modalState.display !== 'none' || modalState.hasShow)) {
          console.log("✅ Modal detectado (puede estar cargando contenido)");
          // Esperar a que el contenido se cargue - intentar múltiples veces
          let intentos = 0;
          const maxIntentos = 10;
          while (intentos < maxIntentos) {
            await page.waitForTimeout(1000);
            const tieneContenido = await page.evaluate(() => {
              const modal = document.querySelector('#modalDetalleCivil, #modalDetalleLaboral, .modal.show');
              if (!modal) return false;
              const tabla = modal.querySelector('table tbody tr');
              return tabla !== null;
            });
            
            if (tieneContenido) {
              console.log(`✅ Contenido del modal cargado después de ${intentos + 1} intentos`);
              break;
            }
            intentos++;
          }
          
          if (intentos >= maxIntentos) {
            // Verificar una última vez
            const ultimaVerificacion = await page.evaluate(() => {
              const modal = document.querySelector('#modalDetalleCivil, #modalDetalleLaboral, .modal.show');
              if (!modal) return { tieneTabla: false };
              return {
                tieneTabla: !!modal.querySelector('table tbody tr'),
                innerHTML: modal.innerHTML.substring(0, 1000)
              };
            });
            
            if (!ultimaVerificacion.tieneTabla) {
              await page.screenshot({ path: 'debug_modal_vacio.png', fullPage: true });
              throw new Error(`Modal abierto pero sin contenido después de ${maxIntentos} intentos. HTML: ${ultimaVerificacion.innerHTML.substring(0, 200)}`);
            }
          }
        } else {
          await page.screenshot({ path: 'debug_sin_modal.png', fullPage: true });
          throw new Error('Modal no se abrió correctamente');
        }
      }
    }

    // Delay final
    await page.waitForTimeout(500);
    console.log("✅ Detalle cargado.");

  } catch (error) {
    console.error('❌ Error abriendo detalle:', error.message);
    await page.screenshot({ path: 'debug_error_detalle.png', fullPage: true });
    throw error;
  }
}

module.exports = { fillForm, openDetalle, openDetalleEspecifico, resetForm };
