require('dotenv').config();
const fs = require('fs');
const path = require('path');

const { startBrowser } = require('./browser');
const { loadConfig } = require('./config');
const { downloadEbook } = require('./ebook');
const { fillForm, openDetalle } = require('./form');
const { closeModalIfExists, goToConsultaCausas } = require('./navigation');
const { extractTable } = require('./table');
const { saveErrorEvidence } = require('./utils');

/**
 * Obtiene el último RIT procesado revisando los archivos de output
 */
function getLastProcessedRIT(outputDir) {
  if (!fs.existsSync(outputDir)) {
    return null;
  }

  const files = fs.readdirSync(outputDir);
  const resultFiles = files
    .filter(file => file.startsWith('resultado_') && file.endsWith('.json'))
    .map(file => {
      // resultado_C_6028_2020.json -> C-6028-2020
      const ritMatch = file.match(/resultado_(.+)\.json/);
      if (ritMatch) {
        const rit = ritMatch[1].replace(/_/g, '-');
        const filePath = path.join(outputDir, file);
        const stats = fs.statSync(filePath);
        return {
          rit,
          mtime: stats.mtime
        };
      }
      return null;
    })
    .filter(item => item !== null)
    .sort((a, b) => b.mtime - a.mtime); // Ordenar por fecha de modificación descendente

  return resultFiles.length > 0 ? resultFiles[0].rit : null;
}

/**
 * Lee el archivo CSV y parsea las causas
 */
function readCausesCSV(csvPath) {
  const content = fs.readFileSync(csvPath, 'utf-8');
  const lines = content.split('\n').filter(line => line.trim());
  const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());

  const causes = [];
  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    if (values.length < headers.length) continue;

    const cause = {};
    headers.forEach((header, index) => {
      cause[header] = values[index] ? values[index].replace(/"/g, '').trim() : '';
    });

    // Validar que tenga RIT válido
    if (cause.rit) {
      // Limpiar RIT: eliminar puntos y espacios, normalizar guiones
      let rit = cause.rit.replace(/\./g, '').trim().toUpperCase();
      
      // Normalizar formato RIT: C-XXXX-YYYY
      const ritParts = rit.split('-');
      if (ritParts.length === 3) {
        // Validar formato correcto
        const tipo = ritParts[0];
        const rol = ritParts[1];
        const year = ritParts[2];
        
        if (tipo.match(/^[CLR]$/) && rol && year && year.length === 4) {
          cause.rit = `${tipo}-${rol}-${year}`;
          causes.push(cause);
        } else {
          console.warn(`⚠️  RIT con formato inválido ignorado: ${cause.rit}`);
        }
      } else if (ritParts.length === 2 && ritParts[0].match(/^[CLR]$/)) {
        // Formato C-XXXXYYYY -> C-XXXX-YYYY
        const numPart = ritParts[1];
        if (numPart.length >= 8) {
          const year = numPart.slice(-4);
          const rol = numPart.slice(0, -4);
          if (/^\d+$/.test(year) && /^\d+$/.test(rol)) {
            cause.rit = `${ritParts[0]}-${rol}-${year}`;
            causes.push(cause);
          }
        }
      } else {
        console.warn(`⚠️  RIT con formato desconocido ignorado: ${cause.rit}`);
      }
    }
  }

  return causes;
}

/**
 * Parsea una línea CSV manejando comillas correctamente
 */
function parseCSVLine(line) {
  const values = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      // Manejar comillas dobles escapadas
      if (i + 1 < line.length && line[i + 1] === '"' && inQuotes) {
        current += '"';
        i++; // Saltar la siguiente comilla
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      values.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  values.push(current);
  
  return values;
}

/**
 * Actualiza el archivo de configuración con los datos de una causa
 */
function updateConfig(cause, configPath, defaultCorte = '90') {
  // Extraer tipo de causa del RIT (C, L, R, etc.)
  const tipoCausa = cause.rit ? cause.rit.split('-')[0] : 'C';
  
  const config = {
    rit: cause.rit,
    competencia: cause.competencia || '1',
    corte: defaultCorte, // Valor por defecto, puede necesitar ajuste
    tribunal: cause.tribunal || '',
    tipoCausa: tipoCausa,
    cliente: cause.cliente || '',
    rut: cause.rut || '',
    caratulado: cause.caratulado || '',
    abogado: cause.abogado_id || '',
    juzgado: cause.juzgado || '',
    folio: cause.folio || ''
  };

  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');
  return config;
}

/**
 * Guarda el progreso del procesamiento
 */
function saveProgress(lastRIT, progressPath) {
  const progress = {
    lastRIT,
    timestamp: new Date().toISOString()
  };
  fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2), 'utf-8');
}

/**
 * Carga el progreso guardado
 */
function loadProgress(progressPath) {
  if (fs.existsSync(progressPath)) {
    try {
      return JSON.parse(fs.readFileSync(progressPath, 'utf-8'));
    } catch (err) {
      return null;
    }
  }
  return null;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getDelayConfig() {
  return {
    base: parseInt(process.env.SCRAPER_DELAY_MS || '2500', 10),
    jitter: parseInt(process.env.SCRAPER_DELAY_JITTER_MS || '2000', 10),
    longBreakEvery: parseInt(process.env.SCRAPER_LONG_BREAK_EVERY || '40', 10),
    longBreakMs: parseInt(process.env.SCRAPER_LONG_BREAK_MS || '60000', 10)
  };
}

function isCaptureEnabled() {
  return process.env.SCRAPER_CAPTURE === '1' || process.env.SCRAPER_CAPTURE === 'true';
}

async function captureStep(page, baseDir, rit, step) {
  if (!isCaptureEnabled()) return;

  const safeRit = rit.replace(/[^a-zA-Z0-9_-]/g, '_');
  const stepDir = path.join(baseDir, 'capturas', safeRit);
  if (!fs.existsSync(stepDir)) fs.mkdirSync(stepDir, { recursive: true });

  const timestamp = Date.now();
  const screenshotPath = path.join(stepDir, `${timestamp}_${step}.png`);
  const htmlPath = path.join(stepDir, `${timestamp}_${step}.html`);

  await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});
  const html = await page.content().catch(() => '');
  if (html) fs.writeFileSync(htmlPath, html, 'utf-8');
}

function createRunLogger(logDir) {
  const runId = Date.now();
  const logPath = path.join(logDir, `metrics_${runId}.json`);
  const data = {
    runId,
    startedAt: new Date().toISOString(),
    items: []
  };

  return {
    add(item) {
      data.items.push(item);
    },
    finalize() {
      data.finishedAt = new Date().toISOString();
      fs.writeFileSync(logPath, JSON.stringify(data, null, 2), 'utf-8');
    }
  };
}

/**
 * Procesa un RIT individual
 */
async function processRIT(cause, configPath, outputDir, session, logger) {
  const logDir = path.resolve(__dirname, 'logs');
  const screenshotPath = path.join(logDir, `pjud_error_${Date.now()}.png`);
  const htmlPath = path.join(logDir, `pjud_error_${Date.now()}.html`);

  // Actualizar configuración con los datos de la causa
  const CONFIG = updateConfig(cause, configPath);

  console.log(`\n🔍 Procesando RIT: ${CONFIG.rit}`);
  console.log(`   Competencia: ${CONFIG.competencia}, Tribunal: ${CONFIG.tribunal}, Tipo: ${CONFIG.tipoCausa}`);

  const { context, page } = session;
  const itemMetrics = {
    rit: CONFIG.rit,
    startedAt: new Date().toISOString(),
    steps: []
  };

  try {
    console.log('🌐 Página cargada:', page.url());

    const stepStartNav = Date.now();
    await closeModalIfExists(page);
    await goToConsultaCausas(page);
    itemMetrics.steps.push({ step: 'go_to_consulta', ms: Date.now() - stepStartNav });
    await captureStep(page, logDir, CONFIG.rit, '01_consulta_causas');

    const stepStartForm = Date.now();
    await fillForm(page, CONFIG);
    itemMetrics.steps.push({ step: 'fill_form', ms: Date.now() - stepStartForm });
    await captureStep(page, logDir, CONFIG.rit, '02_form_enviado');

    const stepStartDetalle = Date.now();
    await openDetalle(page);
    itemMetrics.steps.push({ step: 'open_detalle', ms: Date.now() - stepStartDetalle });
    await captureStep(page, logDir, CONFIG.rit, '03_detalle_abierto');

    const stepStartTable = Date.now();
    const rows = await extractTable(page);
    itemMetrics.steps.push({ step: 'extract_table', ms: Date.now() - stepStartTable, rows: rows.length });
    console.log(`✅ Extraídas ${rows.length} filas`);
    await captureStep(page, logDir, CONFIG.rit, '04_tabla_extraida');

    // Exportar resultados
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    const { exportToJSON, exportToCSV } = require('./exporter');
    exportToJSON(rows, outputDir, CONFIG.rit);
    exportToCSV(rows, outputDir, CONFIG.rit);

    // Descargar PDFs de la tabla
    const { downloadPDFsFromTable } = require('./pdfDownloader');
    await downloadPDFsFromTable(
      page,
      context,
      outputDir,
      CONFIG.rit,
      rows
    );

    // Descargar eBook (opcional, comentado por defecto)
    // await downloadEbook(page, context, CONFIG, path.resolve(__dirname, 'assets/ebook'));

    console.log(`✅ RIT ${CONFIG.rit} procesado exitosamente\n`);
    itemMetrics.success = true;
    itemMetrics.finishedAt = new Date().toISOString();
    logger.add(itemMetrics);
    return { success: true, rit: CONFIG.rit };

  } catch (err) {
    console.error(`❌ Error procesando RIT ${CONFIG.rit}:`, err.message);
    await saveErrorEvidence(page, screenshotPath, htmlPath);
    itemMetrics.success = false;
    itemMetrics.error = err.message;
    itemMetrics.finishedAt = new Date().toISOString();
    logger.add(itemMetrics);
    return { success: false, rit: CONFIG.rit, error: err.message };
  }
}

/**
 * Función principal
 */
(async () => {
  const logDir = path.resolve(__dirname, 'logs');
  const outputDir = path.resolve(__dirname, 'outputs');
  const configPath = path.resolve(__dirname, 'config/pjud_config.json');
  const csvPath = path.resolve(__dirname, '../causa.csv');
  const progressPath = path.resolve(__dirname, 'progress.json');
  const delayConfig = getDelayConfig();

  // Crear directorios necesarios
  [logDir, outputDir].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });

  // Verificar que exista el CSV
  if (!fs.existsSync(csvPath)) {
    console.error(`❌ No se encontró el archivo CSV: ${csvPath}`);
    process.exit(1);
  }

  // Leer causas del CSV
  console.log('📖 Leyendo causas del CSV...');
  const causes = readCausesCSV(csvPath);
  console.log(`✅ Se encontraron ${causes.length} causas en el CSV\n`);

  // Determinar desde dónde continuar
  let startIndex = 0;
  let lastRIT = null;

  // Intentar cargar progreso guardado
  const savedProgress = loadProgress(progressPath);
  if (savedProgress && savedProgress.lastRIT) {
    lastRIT = savedProgress.lastRIT;
    console.log(`📋 Progreso guardado encontrado. Último RIT: ${lastRIT}`);
  } else {
    // Buscar último RIT procesado en los outputs
    lastRIT = getLastProcessedRIT(outputDir);
    if (lastRIT) {
      console.log(`📋 Último RIT procesado encontrado en outputs: ${lastRIT}`);
    } else {
      console.log('📋 No se encontró ningún RIT procesado anteriormente. Iniciando desde el principio.');
    }
  }

  // Encontrar el índice de inicio
  if (lastRIT) {
    startIndex = causes.findIndex(c => c.rit === lastRIT);
    if (startIndex !== -1) {
      startIndex += 1; // Continuar desde el siguiente
      console.log(`▶️  Continuando desde el índice ${startIndex} (después de ${lastRIT})\n`);
    } else {
      console.log(`⚠️  El RIT ${lastRIT} no se encontró en el CSV. Iniciando desde el principio.\n`);
      startIndex = 0;
    }
  }

  // Procesar causas restantes
  const remainingCauses = causes.slice(startIndex);
  console.log(`🚀 Iniciando procesamiento de ${remainingCauses.length} causas restantes...\n`);

  let processed = 0;
  let successful = 0;
  let failed = 0;
  const failedRITs = [];
  let blocked = false;

  const headless = process.env.SCRAPER_HEADLESS !== 'false';
  const slowMo = parseInt(process.env.SCRAPER_SLOWMO || '120', 10);
  const session = await startBrowser(process.env.OJV_URL, { headless, slowMo });
  session.page.setDefaultTimeout(30000);
  session.page.setDefaultNavigationTimeout(60000);
  const logger = createRunLogger(logDir);

  try {
    for (let i = 0; i < remainingCauses.length; i++) {
      const cause = remainingCauses[i];
      
      console.log(`[${i + 1}/${remainingCauses.length}] Procesando causa...`);
      
      const result = await processRIT(cause, configPath, outputDir, session, logger);
      processed++;

      if (result.success) {
        successful++;
        // Guardar progreso después de cada procesamiento exitoso
        saveProgress(result.rit, progressPath);
      } else {
        failed++;
        failedRITs.push(result.rit);
        // También guardar progreso para continuar desde el siguiente
        if (i + 1 < remainingCauses.length) {
          saveProgress(cause.rit, progressPath);
        }

        if (result.error && result.error.toLowerCase().includes('captcha/bloqueo')) {
          blocked = true;
          console.error('⛔ Bloqueo/CAPTCHA detectado. Deteniendo procesamiento masivo.');
          break;
        }
      }

      // Esperar entre procesamientos para no sobrecargar el servidor
      if (i < remainingCauses.length - 1) {
        const waitMs = delayConfig.base + Math.random() * delayConfig.jitter;
        console.log(`⏳ Esperando ${Math.round(waitMs / 1000)}s antes del siguiente procesamiento...\n`);
        await sleep(waitMs);
      }

      // Pausa larga cada cierto número de causas
      if ((i + 1) % delayConfig.longBreakEvery === 0 && i < remainingCauses.length - 1) {
        console.log(`🛑 Pausa larga de ${Math.round(delayConfig.longBreakMs / 1000)}s para evitar bloqueo...`);
        await sleep(delayConfig.longBreakMs);
      }
    }
  } finally {
    logger.finalize();
    await session.browser.close();
  }

  // Resumen final
  console.log('\n' + '='.repeat(60));
  console.log('📊 RESUMEN DEL PROCESAMIENTO');
  console.log('='.repeat(60));
  console.log(`Total procesado: ${processed}`);
  console.log(`✅ Exitosos: ${successful}`);
  console.log(`❌ Fallidos: ${failed}`);
  
  if (failedRITs.length > 0) {
    console.log(`\n⚠️  RITs que fallaron:`);
    failedRITs.forEach(rit => console.log(`   - ${rit}`));
  }

  console.log('\n🧭 Proceso completado.');
  
  // Eliminar archivo de progreso si se completó todo
  if (!blocked && startIndex + processed >= causes.length && failed === 0) {
    if (fs.existsSync(progressPath)) {
      fs.unlinkSync(progressPath);
      console.log('✅ Archivo de progreso eliminado (procesamiento completado)');
    }
  }
})();

